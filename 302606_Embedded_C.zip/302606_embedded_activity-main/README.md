# 302606_embedded_activity
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/8a69f8bb0b71460090f10e981fa6452d)](https://www.codacy.com/gh/rajivadak/302606_embedded_activity/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=rajivadak/302606_embedded_activity&amp;utm_campaign=Badge_Grade)
--------------------------------------
[![Cppcheck](https://github.com/rajivadak/302606_embedded_activity/actions/workflows/Codequality.yml/badge.svg)](https://github.com/rajivadak/302606_embedded_activity/actions/workflows/Codequality.yml)
--------------------------------------------------------

# Activity 1
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/1.png?raw=true" width="1000">

# Activity 2
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/2.png?raw=true" width="1000">

# Activity 3
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/3.png?raw=true" width="1000">

# Activity 4
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/4.png?raw=true" width="1000">

