# Activity 1
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/1.png?raw=true" width="1000">
# Activity 2
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/2.png?raw=true" width="1000">
# Activity 3
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/3.png?raw=true" width="1000">
# Activity 4
<img src="https://github.com/rajivadak/302606_embedded_activity/blob/main/simulation/4.png?raw=true" width="1000">
